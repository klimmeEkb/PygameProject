import os, os.path
import sys
import pygame


need = False


class AnimatedSprite(pygame.sprite.Sprite):
    def __init__(self, sheet, columns, rows, x, y):
        super().__init__(all_sprites)
        self.frames = []
        self.cut_sheet(sheet, columns, rows)
        self.cur_frame = 0
        self.image = self.frames[self.cur_frame]
        self.rect = self.rect.move(x, y)

    def cut_sheet(self, sheet, columns, rows):
        self.rect = pygame.Rect(0, 0, sheet.get_width() // columns, 
                                sheet.get_height() // rows)
        for j in range(rows):
            for i in range(columns):
                frame_location = (self.rect.w * i, self.rect.h * j)
                self.frames.append(sheet.subsurface(pygame.Rect(
                    frame_location, self.rect.size)))

    def update(self):
        self.cur_frame = (self.cur_frame + 1) % len(self.frames)
        self.image = self.frames[self.cur_frame]


def load_image(name, colorkey=None, colorkey2=None):
	fullname = os.path.join('data', name)
	# если файл не существует, то выходим
	if not os.path.isfile(fullname):
		print(f"Файл с изображением '{fullname}' не найден")
		sys.exit()
	image = pygame.image.load(fullname)
	if colorkey is not None:
		image = image.convert()
		if colorkey == -1:
			colorkey = image.get_at((0, 0))
		image.set_colorkey(colorkey)
		if colorkey2 == -2:
			colorkey2 = image.get_at((0, 0))
			image.set_colorkey(colorkey2)
                        
	else:
		image = image.convert_alpha()
	return image


class Start:
	def __init__(self):
		self.width = 17
		self.height = 17
		self.cell_size = 30
		self.x, self.y, self.z = 5, 5, 5
		self.sprite_group = pygame.sprite.Group()
		self.sprite = pygame.sprite.Sprite()
		self.sprite.image = load_image("nether.png")
		self.sprite.rect = self.sprite.image.get_rect()
		self.sprite_group.add(self.sprite)
		self.sprite.rect.x = 0
		self.sprite.rect.y = 0

	def draw(self, screen):
		font = pygame.font.Font(None, 100)
		text = font.render("A hot walk", True, (10, 10, 10))
		text_x = 70
		text_y = 10
		text_w = text.get_width()
		text_h = text.get_height()
		font_exit = pygame.font.Font(None, 100)
		text_exit = font_exit.render("exit", True, (10, 10, 10))
		text_exit_x = 190
		text_exit_y = 310
		text_exit_w = text.get_width()
		text_exit_h = text.get_height()
		screen.blit(text, (text_x, text_y))
		screen.blit(text_exit, (text_exit_x, text_exit_y))


	def get_cell(self, mouse_pos):
		x, y = mouse_pos
		if x in range(self.cell_size * self.width) and y in range(self.cell_size * self.height):
			return x // self.cell_size, y // self.cell_size
		return None

	def on_click(self, mouse_pos):
		cell = self.get_cell(mouse_pos)
		if cell:
			if cell[0] >= 0 and cell[1] >= 0:
				x, y = cell
				if x in range(4, 10) and y in range(5, 8):
					return True
	def exit_click(self, mouse_pos):
		cell = self.get_cell(mouse_pos)
		if cell:
			if cell[0] >= 0 and cell[1] >= 0:
				x, y = cell
				if x in range(4, 10) and y in range(10, 13):
					return True

	def render(self, surface, other, other_exit):
		self.surface = surface
		for i in range(17):
			for j in range(17):
				pygame.draw.rect(self.surface, (10, 10, 10), (j * self.cell_size, i * self.cell_size, self.cell_size, self.cell_size), 1)
		self.sprite_group.draw(self.surface)
		for i in range(5, 8):
			for j in range(6, 11):
				pygame.draw.rect(self.surface, (100, 10, 10), (j * self.cell_size, i * self.cell_size, self.cell_size, self.cell_size))
		for i in range(10, 13):
			for j in range(6, 11):
				pygame.draw.rect(self.surface, (100, 10, 10), (j * self.cell_size, i * self.cell_size, self.cell_size, self.cell_size))
		
		if other:
			for i in range(5, 8):
				for j in range(6, 11):
					pygame.draw.rect(self.surface, (100, 50, 50), (j * self.cell_size, i * self.cell_size, self.cell_size, self.cell_size))
		elif other_exit:
			for i in range(10, 13):
				for j in range(6, 11):
					pygame.draw.rect(self.surface, (100, 50, 50), (j * self.cell_size, i * self.cell_size, self.cell_size, self.cell_size))


class Board:
	def __init__(self):
		self.width = 10
		self.height = 10
		self.length = 10
		self.cell_size = 50
		self.mosx, self.mosy = 25, 25
		self.x, self.y, self.z = 5, 5, 5
		self.left, self.top = 9, 1
		self.sprite_group = pygame.sprite.Group()
		self.sprite = pygame.sprite.Sprite()
		self.sprite.image = load_image("void.png")
		self.sprite.rect = self.sprite.image.get_rect()
		self.sprite_group.add(self.sprite)
		self.sprite.rect.x = 0
		self.sprite.rect.y = 0

	def render(self, surface, krug):
		self.surface = surface
		self.krug = krug
		for i in range(16):
			for j in range(31):
				pygame.draw.rect(self.surface, (10, 10, 10), (j * self.cell_size, i * self.cell_size, self.cell_size, self.cell_size), 1)
		self.sprite_group.draw(self.surface)
		pygame.draw.rect(self.surface, (60, 10, 10), ((9 + krug) * self.cell_size, (1 + krug) * self.cell_size, (13 - 2 * krug) * self.cell_size, (13 - 2 * krug) * self.cell_size))
		pygame.draw.rect(self.surface, (10, 10, 10), ((20 - krug) * self.cell_size, (12 - krug) * self.cell_size, self.cell_size, self.cell_size))

	def get_cell(self, mouse_pos):
		x, y = mouse_pos
		if x in range(self.cell_size * self.left + krug * self.cell_size, self.cell_size * self.left + krug * self.cell_size + (13 - krug) * self.cell_size) and y in range(self.cell_size * self.top + krug * self.cell_size, self.cell_size * self.top + krug * self.cell_size + (13 - krug) * self.cell_size):
			return x // self.cell_size, y // self.cell_size
		return None

	def on_click(self, cell_coords):
		pass

	def get_click(self, mouse_pos):
		cell = self.get_cell(mouse_pos)
		if cell:
			if cell[0] >= 0 and cell[1] >= 0:
				self.on_click(cell)


class End:
	def __init__(self, krug):
		self.width = 17
		self.height = 17
		self.cell_size = 30
		self.sprite_group = pygame.sprite.Group()
		self.sprite = pygame.sprite.Sprite()
		self.sprite.image = load_image("death.png")
		self.sprite.rect = self.sprite.image.get_rect()
		self.sprite_group.add(self.sprite)
		self.sprite.rect.x = 0
		self.sprite.rect.y = 0
		self.krug = krug
		self.flag_fire1 = False
		self.flag_fire2 = False
		self.flag_fire3 = False

	def draw(self, screen):
		font = pygame.font.Font(None, 200)
		text = font.render("Ты погиб", True, (100, 10, 10))
		text_x = 300
		text_y = 10
		text_w = text.get_width()
		text_h = text.get_height()
		font_exit = pygame.font.Font(None, 200)
		text_exit = font_exit.render(f"на {self.krug} круге", True, (100, 10, 10))
		text_exit_x = 300
		text_exit_y = 500
		text_exit_w = text.get_width()
		text_exit_h = text.get_height()
		screen.blit(text, (text_x, text_y))
		screen.blit(text_exit, (text_exit_x, text_exit_y))

	def render(self, surface):
		self.surface = surface
		self.sprite_group.draw(self.surface)

	def fires(self, surface, coords):
		self.surface = surface
		x, y = coords
		if x in range(428, 506) and y in range(256, 311) and not self.flag_fire1:
			fires1 = AnimatedSprite(load_image("fires.png", colorkey=-1, colorkey2=-1), 8, 6, 428, 256)
			self.flag_fire1 = True
		print(x, y)

change = False
change_exit = False
pygame.init()
pygame.display.set_caption('Добро пожаловать! :)')
size = width, height = 510, 510
screen = pygame.display.set_mode(size)
start = Start()
running = True
pygame.mouse.set_visible(False)
all_sprites = pygame.sprite.Group()
sprite = pygame.sprite.Sprite()
sprite.image = load_image("arrow.png", colorkey=-1)
sprite.rect = sprite.image.get_rect()
all_sprites.add(sprite)
sprite.rect.x = 100
sprite.rect.y = 100
skulls = pygame.sprite.Group()
skull = pygame.sprite.Sprite()
skull.image = load_image("skull.png", colorkey=-1)
skull.rect = skull.image.get_rect()
skulls.add(skull)
skull.rect.x = 210
skull.rect.y = 150
while running:
	screen.fill((0, 0, 0))
	for event in pygame.event.get():
		match event.type:
			case pygame.MOUSEBUTTONUP:
				if start.on_click(event.pos):
					need = True
					change = False
					running = False
				elif start.exit_click(event.pos):
					running = False
					change_exit = False
				else:
					change = False
					change_exit = False
			case pygame.MOUSEBUTTONDOWN:
				if start.on_click(event.pos):
					change = True
				elif start.exit_click(event.pos):
					change_exit = True
			case pygame.MOUSEMOTION:
				x, y = event.pos
			case pygame.QUIT:
				running = False
			case pygame.K_RETURN:
				need = True
				running = False
				print("work")
			case pygame.K_ESCAPE:
				running = False
				print("work")
	sprite.rect.x = x
	sprite.rect.y = y
	start.render(screen, change, change_exit)
	start.draw(screen)
	skulls.draw(screen)
	all_sprites.draw(screen)
	pygame.display.flip()
pygame.quit()


if need:
	krug = 0
	pygame.init()
	pygame.display.set_caption('Проектная игра')
	size = width, height = 1550, 800
	screen = pygame.display.set_mode(size)
	board = Board()
	running = True
	pygame.mouse.set_visible(False)
	heroes = pygame.sprite.Group()
	hero = pygame.sprite.Sprite()
	hero.image = load_image("hero_top.png", colorkey=-1)
	hero.rect = sprite.image.get_rect()
	heroes.add(hero)
	hero.rect.x = 10 * 50 + krug * 50
	hero.rect.y = 2 * 50 + krug * 50
	moving = False
	while running:
		screen.fill((0, 0, 0))
		board.render(screen, krug)
		for event in pygame.event.get():
			match event.type:
				case pygame.MOUSEBUTTONDOWN:
					x, y = event.pos
					if (x in range(hero.rect.x - 35, hero.rect.x + 35) and y in range(hero.rect.y - 35, hero.rect.y + 35)):
						moving = True
				case pygame.QUIT:
					running = False
				case pygame.MOUSEMOTION:
					if pygame.mouse.get_focused():
						x, y = event.pos
						if moving:
							xrel, yrel = event.rel
							hero.rect.x += xrel
							hero.rect.y += yrel
				case pygame.MOUSEBUTTONUP:
					if moving:
						if (sprite.rect.x + 50 not in range(450 + krug * 50, 450 + krug * 50 + (13 - krug) * 50) or sprite.rect.y + 50 not in range(50 + krug * 50, 50 + krug * 50 + (13 - krug) * 50) and krug != 10):
							hero.rect.x = 10 * 50 + krug * 50
							hero.rect.y = 2 * 50 + krug * 50
						elif sprite.rect.x + 25 in range((20 - krug) * 50 - 10, (20 - krug) * 50 + 60) and sprite.rect.y + 25 in range((12 - krug) * 50 - 10, (12 - krug) * 50 + 60) and krug != 10:
							krug += 1
							if krug == 6:
								running = False
						moving = False
				case pygame.K_w:
					if hero.rect.y + 30 in range(50 + krug * 50, 50 + krug * 50 + ((13 - krug) * 50)):
						hero.rect.y + 10
				case pygame.K_s:
					if hero.rect.y + 10 in range(50 + krug * 50, 50 + krug * 50 + ((13 - krug) * 50)):
						hero.rect.y - 10
				case pygame.K_d:
					if hero.rect.x + 30 in range(450 + krug * 50, 450 + krug * 50 + (13 - krug) * 50):
						hero.rect.x + 10
				case pygame.K_a:
					if hero.rect.x + 10 in range(450 + krug * 50, 450 + krug * 50 + (13 - krug) * 50):
						hero.rect.x - 10
				case pygame.K_SPACE:
					pass
				case pygame.K_RETURN:
					pass
				case pygame.K_ESCAPE:
					running = False
		sprite.rect.x = x
		sprite.rect.y = y
		heroes.draw(screen)
		all_sprites.draw(screen)
		pygame.display.flip()
	pygame.quit()


	pygame.init()
	pygame.display.set_caption('Итоги')
	size = width, height = 1332, 666
	screen = pygame.display.set_mode(size)
	end = End(krug)
	running = True
	pygame.mouse.set_visible(False)
	clock = pygame.time.Clock()
	screen.fill((0, 0, 0))
	end.render(screen)
	sprite.rect.x = 500
	sprite.rect.y = 300
	end.draw(screen)
	all_sprites.draw(screen)
	pygame.display.flip()
	while running:
		screen.fill((0, 0, 0))
		end.render(screen)
		for event in pygame.event.get():
			match event.type:
				case pygame.MOUSEMOTION:
					if pygame.mouse.get_focused():
						x, y = event.pos
						sprite.rect.x = x
						sprite.rect.y = y
						end.draw(screen)
						all_sprites.draw(screen)
						#fires1.update()
						pygame.display.flip()
				case pygame.MOUSEBUTTONDOWN:
					end.fires(screen, (x, y))
				case pygame.QUIT:
					running = False
		clock.tick(30)
	pygame.quit()
